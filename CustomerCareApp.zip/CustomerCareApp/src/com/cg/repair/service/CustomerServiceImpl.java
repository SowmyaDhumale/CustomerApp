package com.cg.repair.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.repair.beans.Customer;
import com.cg.repair.beans.Expert;
import com.cg.repair.exception.CustomerDetailsNotFoundException;
import com.cg.repair.repo.CustomerRepo;
import com.cg.repair.repo.ExpertRepo;


@Component(value="CustomerService")
public class CustomerServiceImpl implements CustomerService {

	
	@Autowired(required = true)
	private CustomerRepo customerRepo;
	
	@Autowired(required=true)
	private ExpertRepo expertRepo;
	
	@Override
	public Customer registerCustomer(Customer customer) {
		Customer cust =  customerRepo.save(customer);
		return cust;
	}

	@Override
	public ArrayList<Customer> getAllCustomers() {
		
		return (ArrayList<Customer>) customerRepo.findAll();
	}

	@Override
	public List<Expert>  getAllExperts() {
	
		List<Expert> ex = expertRepo.findAll();
		System.out.println("Hello");
		return ex;
	}

	@Override
	public Customer loginCustomer(String phoneNo) throws CustomerDetailsNotFoundException {
		Customer customer1 = customerRepo.findOne(phoneNo);
		if(customer1==null )
			throw new CustomerDetailsNotFoundException("Invalid mobile no");
		else	
			return customer1;}
/*
	@Override
	public Customer updateCustomer(String phoneNo) {
		EntityManager entityManager = null;
		Customer customer = new Customer();
		String str = "update Customer  set rating =: rate where phoneNo=:phone";
		Query query = entityManager.createQuery(str);

		query.setParameter("rate",customer.getRating());
		 query.executeUpdate();
		 return (Customer) query.getSingleResult();
	}*/

	@Override
	public Customer addRating(Customer customer) {
		
		Customer cust =  customerRepo.save(customer);
		return cust;
	}
	

	

}
