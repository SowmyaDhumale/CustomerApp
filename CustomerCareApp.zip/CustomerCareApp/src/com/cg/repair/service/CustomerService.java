package com.cg.repair.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.repair.beans.Customer;
import com.cg.repair.beans.Expert;
import com.cg.repair.exception.CustomerDetailsNotFoundException;

public interface CustomerService {

	public Customer registerCustomer(Customer customer);
	public Customer loginCustomer(String phoneNo) throws CustomerDetailsNotFoundException ;
	//public Customer updateCustomer(String phoneNo);
	public Customer addRating(Customer customer);
	public ArrayList<Customer> getAllCustomers();
	public List<Expert> getAllExperts();
}
