package com.cg.repair.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.repair.beans.Customer;
import com.cg.repair.beans.Expert;



@Controller
public class URIController {

	@RequestMapping(value="/")
	public String getIndexPage() {
		return "indexPage";}
	
	@RequestMapping(value="/loginPage")
	public String getLoginPage() {
		return "loginPage";}
	
	
	@RequestMapping(value="/selectPage")
	public String getSelectPage() {
		return "selectPage";}
	
	@RequestMapping(value="/ratingPage")
	public String getRatingPage() {
		return "ratingPage";}
	
	@RequestMapping(value="/registrationPage")
	public String getRegistrationPage() {
		return "registrationPage";}
	
	@RequestMapping(value="/registrationSuccess")
	public String getRegistrationSuccess() {
		return "registrationSuccess";}
	
	@RequestMapping(value="/ratingSucccessPage")
	public String getRatingSuccessPage() {
		return "ratingSuccessPage";}
	
	@RequestMapping(value="/success")
	public String getSuccess() {
		return "success";}
	
	@RequestMapping(value="/custLogin")
	public String getCustLogin() {
		return "custLogin";}
	
	@RequestMapping(value="/loginOK")
	public String getLoginOK() {
		return "loginOK";}
	
	@RequestMapping(value="/allCustomerPage")
	public String getAllCustomerPage() {
		return "allCustomerPage";
	}
	
	@ModelAttribute("customers")
	public Customer getCustomer(){
		return new Customer();}
	
	@ModelAttribute("expert")
	public Expert getExpert(){
		return new Expert();}
}
