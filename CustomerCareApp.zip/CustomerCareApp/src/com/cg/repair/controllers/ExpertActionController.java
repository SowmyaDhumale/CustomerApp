package com.cg.repair.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.repair.beans.Customer;
import com.cg.repair.beans.Expert;
import com.cg.repair.exception.CustomerDetailsNotFoundException;
import com.cg.repair.service.CustomerService;




@Controller
public class ExpertActionController {

	
	public static String phoneNo;
	public static String item;
	
	@Autowired
	CustomerService customerService;
	
	


	@RequestMapping(value="/registerCustomer")
	public ModelAndView registerCustomer(@Valid @ModelAttribute("customers")Customer customer,BindingResult result) {
			if(result.hasErrors())
				return new ModelAndView("registrationPage");
			 customer=customerService.registerCustomer(customer);
		return new ModelAndView("registrationSuccess", "customer",customer);}
	
	@RequestMapping(value="/loginAdmin")
	public ModelAndView loginAdmin(@ModelAttribute("customers")Customer customer,@RequestParam("userName")String userName, @RequestParam("password")String password) {
		//System.out.println("Hello");
			if(userName.equalsIgnoreCase("admin") && password.equalsIgnoreCase("admin"))
				return new ModelAndView("loginOK");
			if(userName.equalsIgnoreCase(customer.getName()) && password.equalsIgnoreCase(customer.getPhoneNo()))
				return new ModelAndView("ratingPage");
			
		return new ModelAndView("loginPage");}
	
	@RequestMapping(value="/loginCustomer")
	public ModelAndView loginCustomer(@ModelAttribute("customers")Customer customer) {
		phoneNo=customer.getPhoneNo();
			try {
				customer=customerService.loginCustomer(phoneNo);
				return new ModelAndView("ratingPage", "customer",customer);
			} catch (CustomerDetailsNotFoundException e) {
		return new ModelAndView("custLogin", "errorMessage",e.getMessage());}}
	
	/*@RequestMapping(value="/updateCustomer")
	public ModelAndView updateCustomer(@RequestParam("phoneNo") String phoneNo) {
	
		Customer customer = customerService.updateCustomer(phoneNo);
		return new ModelAndView("ratingSuccessPage", "customer", customer);
	}*/
	
	@RequestMapping(value="/updateCustomer")
	public ModelAndView updateCustomer(@ModelAttribute("customers")Customer customer) {
			
			 customer=customerService.addRating(customer);
		return new ModelAndView("ratingSuccessPage", "customer",customer);}

	
	@RequestMapping("/getAll")
	public ModelAndView getAllExperts()
	{
	List<Expert> list=customerService.getAllExperts();
		System.out.println(list);
	
		return new ModelAndView("selectPage","list",list);
		
	}
	
	@RequestMapping(value="/getAllCustomers")
	public ModelAndView getAllCustomers() {
	ArrayList<Customer> customer =customerService.getAllCustomers();
	return  new ModelAndView("allCustomerPage","customer",customer);
	}
	
	@RequestMapping(value="/success/{expertPhoneNo}", method = RequestMethod.GET)
	public ModelAndView getSuccessPage(@PathVariable("expertPhoneNo") String expertPhoneNo)
	{
		Expert expert = new Expert();

		expert.setExpertPhoneNo(expertPhoneNo);
		return new ModelAndView("success","expert",expert);
		
	}
}
