package com.cg.repair.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="expert")
public class Expert {

	
	@Id
	private String item;
	private String expertName;
	private String expertPhoneNo;
	
	
	
	public Expert(String expertName, String expertPhoneNo) {
		super();
		this.expertName = expertName;
		this.expertPhoneNo = expertPhoneNo;
	}



	public Expert(String item) {
		super();
		this.item = item;
	}



	public Expert() {
		super();
	}



	public Expert(String expertName, String item, String expertPhoneNo) {
		super();
		this.expertName = expertName;
		this.item = item;
		this.expertPhoneNo = expertPhoneNo;
	}



	public String getExpertName() {
		return expertName;
	}



	public void setExpertName(String expertName) {
		this.expertName = expertName;
	}



	public String getItem() {
		return item;
	}



	public void setItem(String item) {
		this.item = item;
	}



	public String getExpertPhoneNo() {
		return expertPhoneNo;
	}



	public void setExpertPhoneNo(String expertPhoneNo) {
		this.expertPhoneNo = expertPhoneNo;
	}



	@Override
	public String toString() {
		return "Expert [expertName=" + expertName + ", item=" + item + ", expertPhoneNo=" + expertPhoneNo + "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((item == null) ? 0 : item.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Expert other = (Expert) obj;
		if (item == null) {
			if (other.item != null)
				return false;
		} else if (!item.equals(other.item))
			return false;
		return true;
	}
	
	
	
	
}
