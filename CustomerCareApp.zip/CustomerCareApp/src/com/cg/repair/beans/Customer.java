package com.cg.repair.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="customers")
public class Customer {

	private String name;
	@Id
	

	private String phoneNo;
	
	
	private String email;
	
	private String village;
	
	private String city;
	
	private String state;
	
	private String pinCode;

	private String rating;

	private String item;
		
	public Customer(String name, String email, String village, String city, String state, String pinCode, String rating,
			String item) {
		super();
		this.name = name;
		this.email = email;
		this.village = village;
		this.city = city;
		this.state = state;
		this.pinCode = pinCode;
		this.rating = rating;
		this.item = item;
	}



	public Customer(String phoneNo) {
		super();
		this.phoneNo = phoneNo;
	}



	public Customer() {
		super();
	}



	public Customer(String name, String phoneNo, String email, String village, String city, String state,
			String pinCode, String rating, String item) {
		super();
		this.name = name;
		this.phoneNo = phoneNo;
		this.email = email;
		this.village = village;
		this.city = city;
		this.state = state;
		this.pinCode = pinCode;
		this.rating = rating;
		this.item = item;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getPhoneNo() {
		return phoneNo;
	}



	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getVillage() {
		return village;
	}



	public void setVillage(String village) {
		this.village = village;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public String getState() {
		return state;
	}



	public void setState(String state) {
		this.state = state;
	}



	public String getPinCode() {
		return pinCode;
	}



	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}



	public String getRating() {
		return rating;
	}



	public void setRating(String rating) {
		this.rating = rating;
	}



	public String getItem() {
		return item;
	}



	public void setItem(String item) {
		this.item = item;
	}



	@Override
	public String toString() {
		return "Customer [name=" + name + ", phoneNo=" + phoneNo + ", email=" + email + ", village=" + village
				+ ", city=" + city + ", state=" + state + ", pinCode=" + pinCode + ", rating=" + rating + ", item="
				+ item + "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((phoneNo == null) ? 0 : phoneNo.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (phoneNo == null) {
			if (other.phoneNo != null)
				return false;
		} else if (!phoneNo.equals(other.phoneNo))
			return false;
		return true;
	}
	
	
	

}
