package com.cg.repair.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.cg.repair.beans.Customer;



public interface CustomerRepo extends JpaRepository<Customer, String>,CrudRepository<Customer, String>{

}
